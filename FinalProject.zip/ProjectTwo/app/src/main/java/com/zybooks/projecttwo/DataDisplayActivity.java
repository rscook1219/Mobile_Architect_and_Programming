package com.zybooks.projecttwo;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.projecttwo.databases.UserDatabase;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private static final int UPDATE_GOAL_WEIGHT_REQUEST = 1;

    private UserDatabase userDatabase;
    private EditText inputDate;
    private EditText inputWeight;
    private TextView goalWeightText;
    private RecyclerView recyclerView;
    private WeightAdapter weightAdapter;
    private List<WeightData> weightList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        userDatabase = new UserDatabase(this);
        inputDate = findViewById(R.id.input_date);
        inputWeight = findViewById(R.id.input_weight);
        goalWeightText = findViewById(R.id.goal_weight_text);
        Button addDataButton = findViewById(R.id.add_data_button);
        Button updateGoalWeightButton = findViewById(R.id.update_goal_weight_button);
        recyclerView = findViewById(R.id.data_recycler_view);

        weightList = new ArrayList<>();
        weightAdapter = new WeightAdapter(weightList, new WeightAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(int position) {
                deleteWeight(position);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(weightAdapter);

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeight();
            }
        });

        updateGoalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DataDisplayActivity.this, UpdateGoalWeightActivity.class);
                startActivityForResult(intent, UPDATE_GOAL_WEIGHT_REQUEST);
            }
        });

        loadWeights();
        loadGoalWeight();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == UPDATE_GOAL_WEIGHT_REQUEST && resultCode == RESULT_OK) {
            double updatedGoalWeight = data.getDoubleExtra("goal_weight", 0);
            goalWeightText.setText("" + updatedGoalWeight);
        }
    }

    private void addWeight() {
        String date = inputDate.getText().toString();
        String weightStr = inputWeight.getText().toString();

        if (date.isEmpty() || weightStr.isEmpty()) {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight = Double.parseDouble(weightStr);

        SQLiteDatabase db = userDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);
        long newRowId = db.insert("weight", null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Weight data added", Toast.LENGTH_SHORT).show();
            loadWeights();
        } else {
            Toast.makeText(this, "Error adding weight data", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadWeights() {
        weightList.clear();

        SQLiteDatabase db = userDatabase.getReadableDatabase();
        Cursor cursor = db.query(
                "weight",
                new String[]{"_id", "date", "weight"},
                null,
                null,
                null,
                null,
                "date ASC"
        );

        while (cursor.moveToNext()) {
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
            weightList.add(new WeightData(date, weight));
        }
        cursor.close();

        weightAdapter.notifyDataSetChanged();
    }

    private void deleteWeight(int position) {
        WeightData weightData = weightList.get(position);

        SQLiteDatabase db = userDatabase.getWritableDatabase();
        db.delete("weight", "date = ? AND weight = ?", new String[]{weightData.getDate(), String.valueOf(weightData.getWeight())});

        weightList.remove(position);
        weightAdapter.notifyItemRemoved(position);
        Toast.makeText(this, "Weight data deleted", Toast.LENGTH_SHORT).show();
    }

    private void loadGoalWeight() {
        SQLiteDatabase db = userDatabase.getReadableDatabase();
        Cursor cursor = db.query(
                "goal_weight",
                new String[]{"goal_weight"},
                null,
                null,
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            double goalWeight = cursor.getDouble(cursor.getColumnIndexOrThrow("goal_weight"));
            goalWeightText.setText("" + goalWeight);
            cursor.close();
        } else {
            goalWeightText.setText("Goal Weight Not Set");
        }
    }
}

