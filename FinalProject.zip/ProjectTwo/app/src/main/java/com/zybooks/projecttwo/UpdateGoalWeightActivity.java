package com.zybooks.projecttwo;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.projecttwo.databases.UserDatabase;

public class UpdateGoalWeightActivity extends AppCompatActivity {

    private UserDatabase userDatabase;
    private EditText inputGoalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_goal_weight);

        userDatabase = new UserDatabase(this);
        inputGoalWeight = findViewById(R.id.input_goal_weight);
        Button updateGoalWeightButton = findViewById(R.id.update_goal_weight_button);

        updateGoalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateGoalWeight();
            }
        });
    }

    private void updateGoalWeight() {
        String goalWeightStr = inputGoalWeight.getText().toString();
        if (!goalWeightStr.isEmpty()) {
            double goalWeight = Double.parseDouble(goalWeightStr);
            saveGoalWeight(goalWeight);
        } else {
            Toast.makeText(UpdateGoalWeightActivity.this, "Please enter a valid goal weight", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveGoalWeight(double goalWeight) {
        SQLiteDatabase db = userDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("goal_weight", goalWeight);

        db.delete("goal_weight", null, null); // Clear any existing goal weight
        long newRowId = db.insert("goal_weight", null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Goal weight updated", Toast.LENGTH_SHORT).show();
            Intent resultIntent = new Intent();
            resultIntent.putExtra("goal_weight", goalWeight);
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            Toast.makeText(this, "Error updating goal weight", Toast.LENGTH_SHORT).show();
        }
    }
}
